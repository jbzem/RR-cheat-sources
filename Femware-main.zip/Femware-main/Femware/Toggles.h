#pragma once

namespace Globals {
	struct _Toggles {
		//Gameplay
		bool DynamicFly;
		bool FOVSlider;
		
		bool DeveloperUI;
		bool TrialItems;

		//GUN MODULES
		bool NoRecoil;
		bool NoSpread;

		bool BasicRapidFire;

		//Spawning
		bool FoodSploit;
		bool FoodSploitConfigWindow;

		bool AssetSpawnConfigWindow;

		//Asset Spawn Options
		bool TakePhotoSpawn;
		bool PrintPhotoSpawn;
		bool ShareButtonSpawn;
		bool FoodOverrideSpawn;

		//API Modules
		bool ClothingOverride;
		bool SkinsOverride;
		bool CurrencyOverride;
		bool GiftingOverride;
		bool GiftingConfigWindow;
		bool ConsumableOverride;
	};
	extern _Toggles Toggles;
}