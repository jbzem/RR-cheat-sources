#include "Pointers.h"
#include "Scanner/scanner.h"


/*HMODULE GameModuleUnityPlayer = GetModuleHandleA(OBF("baselib.dll"));
const uint64_t BaseAddressUP = reinterpret_cast<uint64_t>(GameModuleUnityPlayer);
const IMAGE_DOS_HEADER* DOSHeaderUP = reinterpret_cast<IMAGE_DOS_HEADER*>(GameModuleUnityPlayer);
const IMAGE_NT_HEADERS* NtHeadersUP = reinterpret_cast<IMAGE_NT_HEADERS*>(reinterpret_cast<uintptr_t>(GameModuleUnityPlayer) + DOSHeaderUP->e_lfanew);
const DWORD SizeOfImageUP = NtHeadersUP->OptionalHeader.SizeOfImage;*/


void* Pointers::Utils::getAbsoluteAddress(uint64_t offset) {
	HMODULE GameAssembly = GetModuleHandleA(OBF("GameAssembly.dll"));
	if (!GameAssembly)
		return nullptr; //return nothing if gameassembly is null
	return reinterpret_cast<void**>((uint64_t)GameAssembly + offset);
}

void Pointers::Setup() {
	Globals::Bases.spoofAddr = PatternScan<uint64_t*>(OBF("FF 23"), BaseAddressUP, SizeOfImageUP);

	//Setup Exports
	Exports::Exports.Setup();
}