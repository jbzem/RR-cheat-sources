#include "Offsets.h"

namespace Globals {
	_Offsets Offsets;
}