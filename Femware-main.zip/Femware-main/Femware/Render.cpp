#include "Render.h"


void Render::Initialize(LPVOID lpReserved) {
	Setup(lpReserved);
}