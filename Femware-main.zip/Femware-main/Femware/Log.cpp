#include "Log.h"
#include "Flags.h"

void Log::Info(std::string msg) {
	if (!Globals::Flags.IsDeveloper)
		return;
	std::cout << OBF("[Info] ") + msg << std::endl;
}

void Log::Success(std::string msg) {
	if (!Globals::Flags.IsDeveloper)
		return;
	std::cout << OBF("[Success] ") + msg << std::endl;
}

void Log::Error(std::string msg) {
	if (!Globals::Flags.IsDeveloper)
		return;
	std::cout << OBF("[Error] ") + msg << std::endl;
}