#pragma once
#include <iostream>


namespace Log {
	extern void Info(std::string msg);
	extern void Success(std::string msg);
	extern void Error(std::string msg);
}