#pragma once
#include "custom.h"
#include "Hooks.h"

namespace GUI {
	extern bool Opened;
	extern bool IsOpened();

	extern void Render();
	extern void RenderExtra();
}