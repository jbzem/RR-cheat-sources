#pragma once
#include "obfusheader/obfusheader.h"

//Depending on what the user has purchased, set the corresponding values either true or false


namespace Globals {
	struct _Flags {
		//Developer Flag (DISABLE WHEN COMPILING FOR USER)
		static const inline bool IsDeveloper = true;

		//Basic Auth Flag
		bool HasUsedLoader = false;

		//Gameplay Modules
		static const inline bool HasFly = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasFov = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default

		//These Two Come Together
		static const inline bool HasNoRecoil = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasNoSpread = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default

		//Seperate
		static const inline bool HasBasicRapidFire = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default

		//Aimbot & ESP
		static const inline bool HasAimbot = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasESP = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default

		//Misc
		static const inline bool HasDeveloperUIs = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasTrialClothing = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default

		//Spawning Modules
		static const inline bool HasFoodSploit = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasAssetSpawn = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default

		//API Modules
		static const inline bool HasClothing = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasSkins = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasFakeCurrency = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasFakeGifting = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
		static const inline bool HasConsumables = IsDeveloper ? true : false; //Flag is enabled if developer, otherwise it'll be false by default
	};
	extern _Flags Flags;
}