#include "Core.h"
#include "obfusheader/obfusheader.h"
#include "Hooks.h"


void Core::Main() {
	//Setup Console & Skip Auth Check if developer
	if (Globals::Flags.IsDeveloper) {
		Console::Setup(OBF("Femare Dev Logs"));
		Console::Main();

		Globals::Flags.HasUsedLoader = true;
		Hooks::Init();
	}
	else if (!Globals::Flags.IsDeveloper) {
		//TO DO - Implement this section of loading when auth is added
	}
}

BOOL APIENTRY DllMain(HMODULE hMod, DWORD ulReason, LPVOID lpReserved) {
	switch (ulReason) {
	case 1:
		DisableThreadLibraryCalls(hMod);

		std::thread(&Core::Main).detach();
		std::thread(&Render::Initialize, hMod).detach();

		break;
	}
	return TRUE;
}
