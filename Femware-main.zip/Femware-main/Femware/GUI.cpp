#include "GUI.h"
#include "Globals.h"

bool GUI::Opened = false;


bool GUI::IsOpened() {
	return Opened;
}


void GUI::Render() {
	if (!Opened || !Globals::Flags.HasUsedLoader)
		return;

	std::string windowTitle{};

	if (Globals::Flags.IsDeveloper)
		windowTitle = OBF("Femware [Dev] | V1");
	else
		windowTitle = OBF("Femware [Public] | V1");

	ImGui::SetNextWindowPos(ImVec2(ImGui::GetIO().DisplaySize.x / 2, ImGui::GetIO().DisplaySize.y / 2), ImGuiCond_Once);
	ImGui::SetNextWindowSize(ImVec2(345, 455), ImGuiCond_Once);
	ImGui::SetNextWindowSizeConstraints(ImVec2(345, 455), ImGui::GetIO().DisplaySize); //Make min size default window size :3
	ImGui::SetNextWindowBgAlpha(0.8f);

	ImGui::Begin(windowTitle.c_str());

	ImGui::SeparatorText(OBF("Gameplay Modules"));

	if (Globals::Flags.HasFly) ImGui::Custom::Toggle(OBF("Dynamic Fly"), &Globals::Toggles.DynamicFly);

	if (Globals::Flags.HasFov) {
		ImGui::Custom::Toggle(OBF("FOV Slider"), &Globals::Toggles.FOVSlider);
		if (Globals::Toggles.FOVSlider) {
			ImGui::SliderFloat(OBF("FOV Amount"), &Globals::Modifier.FOVAmount, 68.0f, 150.0f);
		}
	}
	ImGui::SeparatorText(OBF("Gun Modules"));

	if (Globals::Flags.HasNoRecoil && Globals::Flags.HasNoSpread) {
		ImGui::Custom::Toggle(OBF("No Recoil"), &Globals::Toggles.NoRecoil);
		ImGui::Custom::Toggle(OBF("No Spread"), &Globals::Toggles.NoSpread);
	}

	if (Globals::Flags.HasBasicRapidFire) ImGui::Custom::Toggle(OBF("Basic Rapid Fire"), &Globals::Toggles.BasicRapidFire);

	if (Globals::Flags.HasAimbot && Globals::Flags.HasESP) 	ImGui::SeparatorText(OBF("Aimbot & ESP")); //Render Separator if user owns aimbot & esp

	if (Globals::Flags.HasDeveloperUIs && Globals::Flags.HasTrialClothing) 	ImGui::SeparatorText(OBF("Misc")); //Render separator if user owns trial clothing & dev uis


	if (Globals::Flags.HasDeveloperUIs && Globals::Flags.HasTrialClothing) { //Go together
		ImGui::Custom::Toggle(OBF("Dev UI"), &Globals::Toggles.DeveloperUI);
		ImGui::Custom::Toggle(OBF("Trial Items"), &Globals::Toggles.TrialItems);
	}

	if (Globals::Flags.HasFoodSploit || Globals::Flags.HasAssetSpawn) ImGui::SeparatorText(OBF("Spawning Modules")); //Render separator if user owns a spawning module

	if (Globals::Flags.HasFoodSploit) {
		ImGui::Custom::Toggle(OBF("Foodsploit"), &Globals::Toggles.FoodSploit);
		if (Globals::Toggles.FoodSploit) {
			ImGui::Spacing();
			ImGui::SameLine();
			ImGui::Custom::Toggle(OBF("Foodsploit Config Window"), &Globals::Toggles.FoodSploitConfigWindow);
		}
	}

	if (Globals::Flags.HasAssetSpawn) ImGui::Custom::Toggle(OBF("Asset Spawn Config Window"), &Globals::Toggles.AssetSpawnConfigWindow);

	if (Globals::Flags.HasClothing || Globals::Flags.HasSkins
		|| Globals::Flags.HasFakeCurrency || Globals::Flags.HasFakeGifting) ImGui::SeparatorText(OBF("Api Modules")); //Render separator if user owns any leaf modules

	if (Globals::Flags.HasClothing) ImGui::Custom::Toggle(OBF("Clothing Override"), &Globals::Toggles.ClothingOverride);
	if (Globals::Flags.HasSkins) ImGui::Custom::Toggle(OBF("Skins Override"), &Globals::Toggles.SkinsOverride);
	if (Globals::Flags.HasFakeCurrency) ImGui::Custom::Toggle(OBF("Currency Override"), &Globals::Toggles.CurrencyOverride);
	if (Globals::Flags.HasConsumables) ImGui::Custom::Toggle(OBF("Consumable Override"), &Globals::Toggles.ConsumableOverride);

	if (Globals::Flags.HasFakeGifting) {
		ImGui::Custom::Toggle(OBF("Gifting Override"), &Globals::Toggles.GiftingOverride);
		if (Globals::Toggles.GiftingOverride) {
			ImGui::Spacing();
			ImGui::SameLine();
			ImGui::Custom::Toggle(OBF("Gifting Config Window"), &Globals::Toggles.GiftingConfigWindow);
		}
	}

	ImGui::End();

	RenderExtra();
}


void GUI::RenderExtra() {
	if (Globals::Toggles.FoodSploitConfigWindow) {
		ImGui::SetNextWindowBgAlpha(0.8f);
		ImGui::Begin(OBF("Foodsploit Config Window"));
		ImGui::End();
	}
	
	if (Globals::Toggles.AssetSpawnConfigWindow) {
		ImGui::SetNextWindowBgAlpha(0.8f);
		ImGui::Begin(OBF("Asset Spawn Config Window"));
		ImGui::End();
	}

	if (Globals::Toggles.GiftingConfigWindow) {
		ImGui::SetNextWindowBgAlpha(0.8f);
		ImGui::Begin(OBF("Gifting Config Window"));
		ImGui::End();
	}
}