#pragma once
#include "Setup.h"


namespace Render { extern void Initialize(LPVOID lpReserved); }