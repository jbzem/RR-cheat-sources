#pragma once

namespace Globals {
	struct _Modifier {
		//Gameplay
		float FOVAmount = 68.0f;

		//Spawning
		
		//FoodSploit
		int FoodAmount = 1;
		float FoodScale = 1.0f;

		//Asset Spawn
		int AssetAmount = 1;
		float AssetScale = 1.0f;
	};
	extern _Modifier Modifier;
}