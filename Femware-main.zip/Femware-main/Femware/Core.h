#pragma once
//Standard C++ Libraries
#include <iostream>
#include <filesystem>
#include <thread>

//Windows API
#include <Windows.h>

//Console
#include "Console.h"

//Globals
#include "Flags.h"

//Render
#include "Render.h"

namespace Core { void Main(); }