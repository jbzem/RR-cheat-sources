#pragma once
#include <iostream>
#include "obfusheader/obfusheader.h"

namespace Globals {
	struct _Offsets {
		//Exports
		const uint64_t il2cpp_domain_get = OBF(0x98F7D0); //get this soon
		const uint64_t il2cpp_thread_attach = OBF(0x98D750); //get this soon

		const uint64_t il2cpp_domain_assembly_open = OBF(0x9EACA0);
		const uint64_t il2cpp_class_from_name = OBF(0x9E9EB0);
		const uint64_t il2cpp_class_get_method_from_name = OBF(0x9EA4B0);

		const uint64_t il2cpp_object_new = OBF(0x9EBBB0);

		//Gameplay
		const uint64_t get_IsFlyingEnabled = OBF(0x188D5B0);
		const uint64_t set_fieldOfView = OBF(0x9750E60);

		const uint64_t get_CurrentRecoilMultiplier = OBF(0x1DDBCB0);
		const uint64_t get_CurrentProjectileSpreadMultiplier = OBF(0x1DDBBE0);

		const uint64_t get_IsOnCooldown = OBF(0x1DDC100);

		const uint64_t get_IsDeveloper = OBF(0x20A4AB0);
		const uint64_t get_LocalAccountIsDeveloper = OBF(0x25D2CE0);
		const uint64_t get_LocalAccountIsModerator = OBF(0x25D2E40);

		const uint64_t IsTrialItem = OBF(0x140B6C0);

		//API
		const uint64_t NotifyServerCertificate = OBF(0x764CAC0);
		const uint64_t Send = OBF(0x7648FB0); //private BestHTTP::HTTPRequest* Send() { }
		const uint64_t Uri = OBF(0x916FBA0); //private Uri(System::String uriString) { }
	};
	extern _Offsets Offsets;
}