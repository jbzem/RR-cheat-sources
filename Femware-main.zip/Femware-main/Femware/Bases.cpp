#include "Bases.h"


namespace Globals {
	_Bases Bases;
}