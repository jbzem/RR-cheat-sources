#pragma once
#include <iostream>
#include <Windows.h>
#include "obfusheader/obfusheader.h"

namespace Globals {
	struct _Bases {
		const uint64_t GameAssembly = (uint64_t)GetModuleHandleA(OBF("GameAssembly.dll"));
		const uint64_t Referee = (uint64_t)GetModuleHandleA(OBF("Referee.dll"));

		const void* spoofAddr = nullptr;
	};
	extern _Bases Bases;
}