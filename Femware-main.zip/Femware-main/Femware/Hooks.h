#pragma once
#include <iostream>
#include <MinHook.h>


namespace Hooks {
	//Pointer Function Signatures
	extern void (*set_timeScale)(float value);

	//Function Signatures
	extern bool(*old_IsFlyingEnabled)(void* object);
	extern bool IsFlyingEnabled(void* object);

	extern void (*old_FOV)(void* object, float pillowiscute);
	extern void FOV(void* object, float pillowiscute);

	extern float (*old_CurrentRecoilMultiplier)(void* object);
	extern float CurrentRecoilMultiplier(void* object);

	extern float (*old_CurrentProjectileSpreadMultiplier)(void* object);
	extern float CurrentProjectileSpreadMultiplier(void* object);

	extern bool (*old_IsOnCooldown)(void* object);
	extern bool IsOnCooldown(void* object);

	extern bool (*old_IsDeveloper)();
	extern bool IsDeveloper();

	extern bool (*old_LocalAccountIsDeveloper)(void* instance);
	extern bool LocalAccountIsDeveloper(void* instance);

	extern bool (*old_LocalAccountIsModerator)(void* instance);
	extern bool LocalAccountIsModerator(void* instance);

	extern bool(*old_IsTrialItem)(void* object,void* avatar,bool boykisser);
	extern bool IsTrialItem(void* object,void* avatar,bool boykisser);


	extern void Init();
}
