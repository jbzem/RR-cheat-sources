#include "Exports.h"


namespace Pointers::Exports {
	U_Exports Exports;

	void U_Exports::Setup() {
		//Basic
		il2cpp_domain_get = (void* (*)()) Utils::getAbsoluteAddress(Globals::Offsets.il2cpp_domain_get);
		il2cpp_thread_attach = (void* (*)(void*)) Utils::getAbsoluteAddress(Globals::Offsets.il2cpp_thread_attach);

		il2cpp_domain_assembly_open = (void* (*)(void*, const char*)) Utils::getAbsoluteAddress(Globals::Offsets.il2cpp_domain_assembly_open);
		il2cpp_class_from_name = (void* (*)(void*, const char*, const char*)) Utils::getAbsoluteAddress(Globals::Offsets.il2cpp_class_from_name);
		il2cpp_class_get_method_from_name = (void* (*)(void*, const char*, int)) Utils::getAbsoluteAddress(Globals::Offsets.il2cpp_class_get_method_from_name);

		il2cpp_object_new = (void* (*)(void*)) Utils::getAbsoluteAddress(Globals::Offsets.il2cpp_object_new);
	}
}