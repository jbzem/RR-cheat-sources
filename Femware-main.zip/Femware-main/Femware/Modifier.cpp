#include "Modifier.h"

namespace Globals {
	_Modifier Modifier;
}