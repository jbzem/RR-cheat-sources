#pragma once
#include <iostream>
#include <Windows.h>
#include "Globals.h"
#include "RetSpoofer/RetSpoofer.hpp"


//Add All Pointers Here
#include "Exports.h"

namespace Pointers::Utils {
	extern void* getAbsoluteAddress(uint64_t offset);
}

namespace Pointers { extern void Setup(); }