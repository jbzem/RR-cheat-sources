#pragma once
#include "Bases.h"
#include "Flags.h"
#include "Offsets.h"
#include "Toggles.h"
#include "Modifier.h"