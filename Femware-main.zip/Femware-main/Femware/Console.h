#pragma once
#include <iostream>
#include <Windows.h>

namespace Console {
	extern void Setup(std::string title);
	extern void Main();
}