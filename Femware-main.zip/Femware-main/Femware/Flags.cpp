#include "Flags.h"


namespace Globals {
	_Flags Flags;
}