#include "Toggles.h"

namespace Globals {
	_Toggles Toggles;
}