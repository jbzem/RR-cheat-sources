#pragma once
//Windows API
#include <Windows.h>

//Direct-X
#include <d3d11.h>
#include <dxgi.h>

//Hook
#include "Kiero/kiero.h"

//GUI & Styling
#include "GUI.h"
#include "Themes.h"
#include "Roboto_Regular.h"

//Backends
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"


namespace Render { extern DWORD WINAPI Setup(LPVOID lpReserved); }