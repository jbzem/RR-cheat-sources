#pragma once
#include "Pointers.h"


namespace Pointers::Exports {
	struct U_Exports {
		//Basic
		void* (*il2cpp_domain_get)();
		void* (*il2cpp_thread_attach)(void* domain);

		//Class getting, etc
		void* (*il2cpp_domain_assembly_open)(void* domain, const char* image);
		void* (*il2cpp_class_from_name)(void* image, const char* nameSpaze, const char* klass);
		void* (*il2cpp_class_get_method_from_name)(void* klass, const char* methodName, int argsCount);

		//Creating C# types
		void* (*il2cpp_object_new)(void* klass);
		

		void Setup();
	};
	extern U_Exports Exports;
}