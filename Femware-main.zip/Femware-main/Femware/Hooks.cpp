#include "Hooks.h"
#include "Pointers.h" //Adds Globals

#define HOOK_A(offset, detour) \
    MH_CreateHook(reinterpret_cast<void**>((uint64_t)GetModuleHandleA(OBF("GameAssembly.dll")) + offset), &detour, (void**)&old_##detour); \
    MH_EnableHook(reinterpret_cast<void**>((uint64_t)GetModuleHandleA(OBF("GameAssembly.dll")) + offset))

#define HOOK_B(offset, detour, orig) \
    MH_CreateHook(reinterpret_cast<void**>((uint64_t)GetModuleHandleA(OBF("GameAssembly.dll")) + offset), &detour, (void**)&orig); \
    MH_EnableHook(reinterpret_cast<void**>((uint64_t)GetModuleHandleA(OBF("GameAssembly.dll")) + offset))


#define OFFSET(a) reinterpret_cast<void**>((uint64_t)GetModuleHandleA(OBF("GameAssembly.dll")) + a)

void (*Hooks::set_timeScale)(float randomParamter) = (void(*)(float)) OFFSET(0x0);

bool (*Hooks::old_IsFlyingEnabled)(void* object);
bool Hooks::IsFlyingEnabled(void* object) {
	if (object != nullptr && Globals::Toggles.DynamicFly)
		return true;
	return old_IsFlyingEnabled(object);
}

void (*Hooks::old_FOV)(void* object, float pillowiscute);
void Hooks::FOV(void* object, float pillowiscute) {
	if (object != nullptr && Globals::Toggles.FOVSlider)
		pillowiscute = Globals::Modifier.FOVAmount;
	return old_FOV(object, pillowiscute);
}

float(*Hooks::old_CurrentRecoilMultiplier)(void* object);
float Hooks::CurrentRecoilMultiplier(void* object) {
	if (object != nullptr && Globals::Toggles.NoRecoil)
		return 0;

	return old_CurrentRecoilMultiplier(object);
}

float(*Hooks::old_CurrentProjectileSpreadMultiplier)(void* object);
float Hooks::CurrentProjectileSpreadMultiplier(void* object) {
	if (object != nullptr && Globals::Toggles.NoSpread)
		return 0;

	return old_CurrentProjectileSpreadMultiplier(object);
}

//Rapid Fire | RJ is cute <3
bool (*Hooks::old_IsOnCooldown)(void* object);
bool Hooks::IsOnCooldown(void* object) {
	if (object != nullptr && Globals::Toggles.BasicRapidFire)
		return false;
	return old_IsOnCooldown(object);
}

bool (*Hooks::old_IsDeveloper)();
bool Hooks::IsDeveloper() {
	if (Globals::Toggles.DeveloperUI)
		return true;
	return old_IsDeveloper();
}

bool (*Hooks::old_LocalAccountIsDeveloper)(void* instance);
bool Hooks::LocalAccountIsDeveloper(void* instance) {
	if (instance != nullptr && Globals::Toggles.DeveloperUI)
		return true;
	return old_LocalAccountIsDeveloper(instance);
}

bool (*Hooks::old_LocalAccountIsModerator)(void* instance);
bool Hooks::LocalAccountIsModerator(void* instance) {
	if (instance != nullptr && Globals::Toggles.DeveloperUI)
		return true;
	return old_LocalAccountIsModerator(instance);
}

//	private static void set_timeScale(float value) { }

//kinda working!
bool(*Hooks::old_IsTrialItem)(void* object,void* avatar,bool boykisser);
bool Hooks::IsTrialItem(void* object,void* avatar,bool boykisser) {
	if (object != nullptr && Globals::Toggles.TrialItems)
		return false;
	return old_IsTrialItem(object,avatar,boykisser);
}

void Hooks::Init() {
	//Initialize Pointers
	Pointers::Setup();

	MH_Initialize();
	//Fly & FOV
	HOOK_B(Globals::Offsets.get_IsFlyingEnabled, IsFlyingEnabled, old_IsFlyingEnabled);
	HOOK_B(Globals::Offsets.set_fieldOfView, FOV, old_FOV);
	
	//No Recoil & Spread
	HOOK_B(Globals::Offsets.get_CurrentRecoilMultiplier, CurrentRecoilMultiplier, old_CurrentRecoilMultiplier);
	HOOK_B(Globals::Offsets.get_CurrentProjectileSpreadMultiplier, CurrentProjectileSpreadMultiplier, old_CurrentProjectileSpreadMultiplier);

	//Basic Rapid Fire
	HOOK_B(Globals::Offsets.get_IsOnCooldown, IsOnCooldown, old_IsOnCooldown);
	
	//Dev UIs
	HOOK_B(Globals::Offsets.get_IsDeveloper, IsDeveloper, old_IsDeveloper);
	HOOK_B(Globals::Offsets.get_LocalAccountIsDeveloper, LocalAccountIsDeveloper, old_LocalAccountIsDeveloper);
	HOOK_B(Globals::Offsets.get_LocalAccountIsModerator, LocalAccountIsModerator, old_LocalAccountIsModerator);

	//Trial Clothing
	HOOK_B(Globals::Offsets.IsTrialItem, IsTrialItem, old_IsTrialItem);
}