#include "Console.h"
#include "obfusheader/obfusheader.h"
#include "Log.h"

void Console::Setup(std::string title) {
	AllocConsole();
	SetConsoleTitleA(title.c_str());
	FILE* f{};
	freopen_s(&f, OBF("CONOUT$"), OBF("w"), stdout);
}


void Console::Main() {
	Log::Info(OBF("Developer Mode Loaded <3"));
	Sleep(OBF(1500));
	system(OBF("cls"));
}